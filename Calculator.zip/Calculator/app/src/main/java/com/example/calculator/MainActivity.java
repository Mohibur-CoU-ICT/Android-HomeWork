package com.example.calculator;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;

public class MainActivity extends AppCompatActivity implements View.OnClickListener {

    private EditText number1, number2;
    private TextView resultText;
    private Button plusButton, minusButton, divButton, mulButton, minimumButton, maximumButton;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);


    }

    @Override
    public void onClick(View v) {



            number1 = findViewById(R.id.num1);
            number2 = findViewById(R.id.num2);

            resultText = findViewById(R.id.result);

            plusButton = findViewById(R.id.addition);
            minusButton = findViewById(R.id.subtraction);
            divButton = findViewById(R.id.divition);
            mulButton = findViewById(R.id.multiplication);
            minimumButton = findViewById(R.id.min);
            maximumButton = findViewById(R.id.max);

            plusButton.setOnClickListener(this);
            minusButton.setOnClickListener(this);
            divButton.setOnClickListener(this);
            mulButton.setOnClickListener(this);
            minimumButton.setOnClickListener(this);
            maximumButton.setOnClickListener(this);

            String stringNumber1 = number1.getText().toString();
            final double doubleNumber1 = Double.parseDouble(stringNumber1);

            String stringNumber2 = number2.getText().toString();
            final double doubleNumber2 = Double.parseDouble(stringNumber2);

            if(v.getId()==R.id.addition)
            {
                double doubleAddition = doubleNumber1 + doubleNumber2;
                resultText.setText(Double.toString(doubleAddition));
            }
            else if(v.getId()==R.id.subtraction)
            {
                double doubleSubtraction = doubleNumber1 - doubleNumber2;
                resultText.setText(Double.toString(doubleSubtraction));
            }
            else if(v.getId()==R.id.multiplication)
            {
                double doubleMultiplication = doubleNumber1 * doubleNumber2;
                resultText.setText(Double.toString(doubleMultiplication));
            }
            else if(v.getId()==R.id.divition)
            {
                double doubleDivition = doubleNumber1 - doubleNumber2;
                resultText.setText(Double.toString(doubleDivition));
            }
            else if(v.getId()==R.id.min)
            {
                double doubleMin = doubleNumber1 - doubleNumber2;
                resultText.setText(Double.toString(doubleMin));
            }
            else if(v.getId()==R.id.max)
            {
                double doubleMax = doubleNumber1 - doubleNumber2;
                resultText.setText(Double.toString(doubleMax));
            }


    }

}
